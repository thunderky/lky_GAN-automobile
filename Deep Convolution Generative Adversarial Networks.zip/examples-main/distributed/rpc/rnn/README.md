Distributed RNN Model Parallel Example

This example shows how to build an RNN model using RPC where different
components of the RNN model can be placed on different workers.

```
pip install -r requirements.txt
python main.py
```
