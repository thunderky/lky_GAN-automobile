---
name: "\U0001F680 Feature request"
about: Suggest a new example or an improvement to the repo

---

<!--
Thank you for suggesting an idea to improve pytorch/examples

Please fill in as much of the template below as you're able.
-->

## Is your feature request related to a problem? Please describe.
<!-- Please describe the problem you are trying to solve. -->

## Describe the solution
<!-- Please describe the desired behavior. -->

## Describe alternatives solution
<!-- Please describe alternative solutions or features you have considered. -->
